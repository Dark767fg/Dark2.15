const iklan = () => { 
	return `           
╔══✪〘 PROPAGANDA 〙✪══
║
╠═══════════════════════════
╠➥ *LISTA DE ALUGUEL E CRIAR BOTS:*
╠➥ *ALUGUEL: 10 / GRUPO (MÊS)*
╠➥ *CRIAR: 35 (PODE SER PROPRIETÁRIO)*
╠➥ *PODE PAGAR ATRAVÉS DE:*
╠➥ *MERCADO PAGO, BOLETO,*
╠═══════════════════════════
╠➥ *VANTAGENS*
╠➥ *wa.me/+5521982310081*
║
╚═〘  Dark2k15 〙
`
}
exports.iklan = iklan